---
title: "Smart Water Distribution System"
oneLiner: "A prototype distribution + monitoring concept to improve water delivery efficiency and detect issues using low-cost sensing + control."
date: "202X"
image: "/projects/water.png"
skills: ["IoT", "Sensors", "Embedded", "Control", "Systems"]
highlights:
  - "Developed a functional prototype demonstrating monitoring + decision logic."
  - "Focused on practical constraints: low-cost hardware and field-friendly design choices."
awards: []
---

## Summary
(Add later — you’ll share the PDF and we’ll write a crisp, hiring-friendly summary.)

## What I built
- Hardware prototype
- Sensor/data pipeline
- Control logic / decision rules
- Validation approach

## Next improvements
- Calibration, robustness, packaging, long-term logging
