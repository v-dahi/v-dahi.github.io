---
title: "FSAE: IIoT-Based Digital Twin"
oneLiner: "An Industrial IoT digital twin pipeline that connects physical assets to live telemetry, status, and analytics for real-time decisions."
date: "2026"
image: "/projects/fsae.png"
skills: ["IIoT", "Digital Twin", "MQTT", "Python", "Dashboards", "Systems"]
highlights:
  - "Built an end-to-end data flow from device telemetry to a live twin view."
  - "Designed the twin state model (reported vs desired) and system architecture for reliability."
awards: []
---

## Summary
(Add later — you’ll share the PDF and we’ll make this strong.)

## Architecture
- Devices / data source
- Transport (MQTT / API)
- Twin model
- Dashboard / analytics

## Results
- Latency / stability / any metrics you have

## Next improvements
- Security/auth, provisioning, scaling, alerting
